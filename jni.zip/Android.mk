LOCAL_PATH := $(call my-dir)

XDL_SOURCES := $(patsubst $(LOCAL_PATH)/%,%, $(wildcard $(LOCAL_PATH)/xdl/*.c))

# ============================================================
#  1) 注入器：独立可执行文件 il2cpp_dumper
#     用法: il2cpp_dumper <pid或包名> [选项]
# ============================================================
include $(CLEAR_VARS)
LOCAL_MODULE := il2cpp_dumper
LOCAL_SRC_FILES := \
    injector/main.cpp \
    injector/injector.cpp \
    common/proc_maps.cpp \
    common/elf_remote.cpp
LOCAL_C_INCLUDES := $(LOCAL_PATH)/common
LOCAL_CPPFLAGS := -std=c++17 -Wall -Wno-unused-parameter
LOCAL_LDLIBS := -llog -ldl
LOCAL_LDFLAGS := -Wl,--hash-style=both
include $(BUILD_EXECUTABLE)

# ============================================================
#  2) 注入到游戏进程里的 payload（真正干活的部分）
#     生成 libil2cppdump_payload.so
# ============================================================
include $(CLEAR_VARS)
LOCAL_MODULE := il2cppdump_payload
LOCAL_SRC_FILES := \
    payload/payload.cpp \
    payload/il2cpp_dump.cpp \
    $(XDL_SOURCES)
LOCAL_C_INCLUDES := \
    $(LOCAL_PATH)/common \
    $(LOCAL_PATH)/xdl/include \
    $(LOCAL_PATH)/payload
LOCAL_CPPFLAGS := -std=c++17 -Wall -Wno-unused-parameter
LOCAL_CFLAGS := -Wall
LOCAL_LDLIBS := -llog -ldl
LOCAL_LDFLAGS := -Wl,--hash-style=both
include $(BUILD_SHARED_LIBRARY)
