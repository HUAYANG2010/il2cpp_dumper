# AIDE 内置 ndk-build 使用的工程配置
# 若要减小体积/只支持 64 位游戏，可把 arm64-v8a armeabi-v7a 改成只要一个

APP_ABI := arm64-v8a armeabi-v7a
APP_PLATFORM := android-21
APP_STL := c++_static
APP_OPTIM := release
APP_CPPFLAGS := -std=c++17 -fno-exceptions -fno-rtti
APP_CFLAGS := -O2
